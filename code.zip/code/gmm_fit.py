###################################################################
#
# This file is 4th file in the project to fit a mixture model 
# to validate that we can obtain a consisitent group of clusters 
# as those obtained from K-means.
#
# In this file, I fit a mixture model and saved the center of
# best model as gmm_c8
#

###################################################################


###################################################################
# Package Import
from sklearn import mixture
from sklearn.cluster import KMeans, AgglomerativeClustering
import numpy as np
import collections
import matplotlib.pyplot as plt
import pandas as pd
from scipy.cluster.hierarchy import dendrogram
import seaborn as sns
###################################################################


###################################################################
# data import
main_matrix = np.loadtxt('./data/main_matrix.txt', delimiter=' ')
###################################################################


###################################################################
# Training GMM using both AIC and BIC
aic_tb=[]
bic_tb=[]

for j in range(3,9):
    
    print("----- Components "+str(j)+" fitting -----")
    
    gmm = mixture.GaussianMixture(n_components=j, covariance_type='full')
    gmm.fit(main_matrix)    
    
    bic = gmm.bic(main_matrix)
    aic = gmm.aic(main_matrix)
    bic_tb.append(bic)
    aic_tb.append(aic)
    
    print('----- Converge:'+str(gmm.converged_)+' ---- ')
    
print('----- AIC Select '+str(aic_tb.index(min(aic_tb))+3)+' Components With Val of '+ str(min(aic_tb))+" -----")
print('----- BIC Select '+str(bic_tb.index(min(bic_tb))+3)+' Components With Val of '+ str(min(bic_tb))+" -----")
###################################################################


###################################################################
 # Refit after deciding 8 as the optimal # of components
gmm = mixture.GaussianMixture(n_components=aic_tb.index(min(aic_tb))+3, covariance_type='full')
gmm.fit(main_matrix)
np.savetxt("./data/gmm_c.csv", gmm.means_, delimiter=",")
###################################################################